module simpleMinds {
	requires java.desktop;
}